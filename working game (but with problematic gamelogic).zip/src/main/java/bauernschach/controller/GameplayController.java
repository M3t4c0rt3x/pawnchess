package bauernschach.controller;

import bauernschach.model.Bauernschach;
import bauernschach.model.Bauernschach.OperationStatus;
import bauernschach.model.GameState;
import bauernschach.model.board.ChessBoard;
import bauernschach.model.board.ChessPiece;
import bauernschach.model.board.ChessPiece.Color;
import bauernschach.model.board.Coordinate;
import bauernschach.model.board.Move;
import bauernschach.model.observable.Observer;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;

public class GameplayController implements Observer {

  private Bauernschach game = new Bauernschach();
  private Circle selectedCircle;
  private String player;

  @FXML
  private GridPane chessBoardGridPane;

  @FXML
  void initialize() {
    game.subscribe(this);
    displayCurrentBoard();
    player = game.getGameState().getCurrentRound().toString();
  }


  @Override
  public void updateState(GameState state) {
    player = game.getGameState().getCurrentRound().toString();
    System.out.println("New round -> current player is: " + player);
    displayCurrentBoard();
  }

  private void displayCurrentBoard() {
    final GameState gameState = game.getGameState();
    //final ChessBoard chessBoard = gameState.getChessBoard();
    chessBoardGridPane.getChildren().clear();

    /*int numColums = gameState.getChessBoard().getNumColumns();
    int numRows = gameState.getChessBoard().getNumRows();
    for (int actualRow = 0; actualRow < numRows; actualRow++) {
      for (int actualColumn = 0; actualColumn < numColums; actualColumn++) { */
    for (int actualRow = 0; actualRow < 8; actualRow++) {
      for (int actualColumn = 0; actualColumn < 8; actualColumn++) {
        ChessPiece currentPiece = gameState.getChessBoard()
            .getPieceAt(Coordinate.of(actualRow, actualColumn));
        if (currentPiece.getColor() != null) {
          //System.out.println(currentPiece);
          int id = currentPiece.getId();
          if (currentPiece.getColor() == Color.BLACK) {
            Circle currentCircle = createNewClickableCircle(Paint.valueOf("BLACK"), id);
            chessBoardGridPane.add(currentCircle, actualColumn, actualRow);
            GridPane.setHalignment(currentCircle, HPos.CENTER);
          } else {
            Circle currentCircle = createNewClickableCircle(Paint.valueOf("WHITE"), id);
            chessBoardGridPane.add(currentCircle, actualColumn, actualRow);
            GridPane.setHalignment(currentCircle, HPos.CENTER);
          }
        }
      }
    }
  }

  private Circle createNewClickableCircle(Paint paint, int id) {
    Circle actualCircle = new Circle(30, paint);
    actualCircle.setOnMouseClicked(e -> {
      if (paint == Paint.valueOf(player)) {
        if (selectedCircle != null) {
          selectedCircle.setFill(Paint.valueOf(player));
          game.deselectPiece();
        }
        selectedCircle = actualCircle;
        selectedCircle.setFill(Paint.valueOf("BLUE"));
        game.selectPieceById(id);
        List<Move> possibleMoves = game.getGameState().getSelectedPiece().getPossibleMoves();
        //System.out.println("Paint:" + paint.toString() + ", ID: " + id);
        int moveCount = -1;
        for (Move move : possibleMoves) {
          moveCount++;
          System.out.println(move.getNewCoordinate().toString());
          /*int targetId = game.getGameState().getChessBoard().getPieceAt(Coordinate.of(move.getNewCoordinate().getRow(), move.getNewCoordinate().getRow())).getId();
          System.out.println("TargetID: " + targetId); */
          Circle targetPositionCircle = createNewTargetPositionCircle(moveCount,
              move.getNewCoordinate().getRow(), move.getNewCoordinate().getColumn());
          chessBoardGridPane.add(targetPositionCircle,
              move.getNewCoordinate().getColumn(), move.getNewCoordinate().getRow());
          GridPane.setHalignment(targetPositionCircle, HPos.CENTER);

        }
      }
    });
    return actualCircle;
  }

  private Circle createNewTargetPositionCircle(int id, int row, int column) {
    Circle actualCircle = new Circle(10, Paint.valueOf("green"));
    actualCircle.setOnMouseClicked(e -> {
      OperationStatus operationStatus = game.move(id);
      if (operationStatus == OperationStatus.FAIL) {
        System.out.println("This move is not possible.");
      }
    });
    return actualCircle;
  }
}
