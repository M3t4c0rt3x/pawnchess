package bauernschach.controller;

public class VictoryController {

}
